#include<stdio.h>
int main()
{
    int i;
    printf("Square of first 10 natural numbers:");
    for(i=1;i<=10;i++)
    {
        printf(" %d",i*i);
    }
    getch();
    return 0;
}
