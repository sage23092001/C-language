#include<stdio.h>
int main()
{
    int i;
    printf("First 10 even natural numbers:");
    for(i=1;i<=20;i++)
    {
        if((i%2)==0)
            printf(" %d",i);
    }
    getch();
    return 0;
}
