#include<stdio.h>
int main()
{
    int i;
    printf("First 10 natural numbers: ");
    for(i=1;i<=10;i++)
    {
        printf(" %d",i);
    }
    getch();
    return 0;
}
