#include<stdio.h>
int main()
{
    int i;
    printf("First 10 natural numbers in reverse: ");
    for(i=10;i>=1;i--)
    {
        printf(" %d",i);
    }
    getch();
    return 0;
}
