#include<stdio.h>
int main()
{
    int i;
    for(i=1;i<=5;i++)
    {
        printf("MySirG\n");
    }
    getch();
    return 0;
}
