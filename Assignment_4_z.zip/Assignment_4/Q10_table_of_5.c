#include<stdio.h>
int main()
{
    int i;
    printf("Table of 5:");
    for(i=1;i<=10;i++)
    {
        printf(" %d",5*i);
    }
    getch();
    return 0;
}
