#include<stdio.h>
int main()
{
    int i,n,m;
    printf("Enter two numbers: ");
    scanf("%d %d",&n,&m);
    for(i=1;i<=n*m;i++)
    {
        if((i%n)==0)
        {
            if((i%m)==0)
            {
                printf("%d is LCM of %d and %d",i,n,m);
                break;
            }
        }
    }
    getch();
    return 0;
}
