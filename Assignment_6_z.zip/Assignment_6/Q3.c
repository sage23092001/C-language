#include<stdio.h>
int main()
{
    int i,n,sum=0;
    printf("Sum of first n odd natural numbers: ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=sum+(2*i-1);
    }
    printf("Sum of first %d odd natural numbers is %d",n,sum);
    getch();
    return 0;

}
