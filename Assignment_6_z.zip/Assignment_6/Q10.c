#include<stdio.h>
int main()
{
    int n,i,d;
    printf("Enter a number: ");
    scanf("%d",&n);
    d=n;
    for(i=0;n>0;i++)
    {
        n=n/10;
    }
    printf("%d is %d digit number",d,i);
    getch();
    return 0;
}
