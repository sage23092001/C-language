#include<stdio.h>
int main()
{
    int i,n,x;
    printf("Enter a number: ");
    scanf("%d",&n);
    x=n;
    for(i=0;n>0;i++)
    {
        n=n/10;
    }
    printf("%d is %d digit number",x,i);
    getch();
    return 0;
}
