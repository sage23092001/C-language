#include<stdio.h>
int main()
{
    int i,n,sum;
    printf("Sum of first n even natural numbers: ");
    scanf("%d",&n);
    n=n*2;
    for(i=1;i<=n;i++)
    {
        if((i%2)==0)
        {
            sum=sum+i;
        }
    }
    printf("Sum of first %d natural number is %d",n/2,sum);
    getch();
    return 0;
}
