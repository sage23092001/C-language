#include<stdio.h>
int main()
{
    int i,n,f=1;
    printf("Enter a number: ");
    scanf("%d",&n);
    for(i=n;i>=1;i--)
    {
        f=f*i;
    }
    printf("Factorial of %d is %d",n,f);
    getch();
    return 0;
}
