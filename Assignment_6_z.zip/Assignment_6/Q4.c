#include<stdio.h>
int main()
{
    int i,n,sum;
    printf("Sum of first n square of natural numbers: ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=sum+i*i;
    }
    printf("Sum of first %d square of natural numbers is %d",n,sum);
    getch();
    return 0;
}
