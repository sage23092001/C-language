#include<stdio.h>
int main()
{
   int i,j,k,n;
   for(i=0;i<=5;i++)
   {
       for(j=1;j<=(5-i);j++)
       {
           printf("*");
       }
       for(k=1;k<=2*i;k++)
       {
           printf(" ");
       }
       for(n=1;n<=(5-i);n++)
       {
           printf("*");
       }
       printf("\n");
   }
    return 0;
}
