#include<stdio.h>
int main()
{
    int i,j,k,n,c;
    for(i=1;i<=5;i++)
    {
        c='A';
        for(j=1;j<=5-i;j++)
        {
            printf(" ");
        }
        for(k=1;k<=5-(j-1);k++)
        {
            printf("%c",c++);
        }
        c--;
        c--;
        for(n=k-1-1;n>=1;n--)
        {
            printf("%c",c);
            c--;
        }
        printf("\n");
    }
    return 0;
}
