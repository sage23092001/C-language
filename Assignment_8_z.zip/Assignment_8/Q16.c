#include<stdio.h>
int main()
{
    int i,j,k,n;
    for(i=0;i<=3;i++)
    {
        for(j=1;j<=8-i*2;j++)
        {
            printf(" ");
        }
        printf("*");
        if(i>0)
        {
           for(k=1;k<=2*(2*i-1)+1;k++)
           {
              printf(" ");
           }
           printf("*");
        }
        printf("\n\n");
    }
    if(i==4)
    {
        for(i=1;i<=9;i++)
        {
            printf("* ");
        }
    }
    return 0;
}
