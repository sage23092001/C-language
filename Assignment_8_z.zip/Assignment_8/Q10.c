#include<stdio.h>
int main()
{
    int i,j,k,n;
    for(i=0;i<=4;i++)
    {
        for(j=1;j<=4-i;j++)
        {
            printf("%d",j);
        }
        for(k=1;k<=2*i-1;k++)
        {
            printf(" ");
        }
        if(i==0)
        {
            for(n=j-1-1;n>=1;n--)
            {
               printf("%d",n);
            }
        }
        if(i>0)
        {
            for(n=j-1;n>=1;n--)
            {
               printf("%d",n);
            }
        }
        printf("\n");
    }
    return 0;
}
