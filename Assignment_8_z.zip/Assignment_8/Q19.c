#include<stdio.h>
int main()
{
    int i,j,k,n,m;
    for(i=0;i<=2;i++)
    {
        m=3;
        m=m-i;
        for(j=1;j<=4-2*i;j++)
        {
            printf(" ");
        }
        for(k=1;k<=5+2*i;k++)
        {
            printf("* ");
        }
        for(n=m;n>=1;n--)
        {
            for(j=1;j<=2*(2*m-1);j++)
            {
                printf(" ");
            }
            break;
        }
        for(k=1;k<=5+2*i;k++)
        {
            printf("* ");
        }
        for(j=1;j<=4-2*i;j++)
        {
            printf(" ");
        }
        printf("\n\n");
    }
    for(i=10;i>=1;i--)
    {
        if(i==10)
        {
            for(j=1;j<=7;j++)
            {
                printf(" *");
            }
            printf("  MySirG  ");
            for(j=1;j<=7;j++)
            {
                printf("* ");
            }
        }
        if(i<10)
        {
            for(j=1;j<=2*(10-i);j++)
            {
                printf(" ");
            }
            for(k=1;k<=2*i-1;k++)
            {
                printf("* ");
            }
        }
        printf("\n\n");
    }
    return 0;
}
