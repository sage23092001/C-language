#include<stdio.h>
int main()
{
    int i,j;
    for(i=0;i<=3;i++)
    {
        printf("*");
        if(i>0)
        {
        for(j=1;j<=i*2-1;j++)
        {
            printf(" ");
        }
        {
            printf("*");
        }
        }
        printf("\n\n");
    }
    for(i=1;i<=5;i++)
    {
        printf("* ");
    }
    return 0;
}
