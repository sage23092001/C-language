#include<stdio.h>
int main()
{
    int i,j,k,n;
    for(i=0;i<=4;i++)
    {
        for(j=1;j<=8-i*2;j++)
        {
            printf(" ");
        }
        for(k=1;k<=2*i+1;k++)
        {
            printf("* ");
    }
        printf("\n\n");
    }
     for(i=3;i>=0;i--)
    {
        for(j=1;j<=8-i*2;j++)
        {
            printf(" ");
        }
        for(k=1;k<=2*i+1;k++)
        {
            printf("* ");
        }
        printf("\n\n");
    }
    return 0;
}
