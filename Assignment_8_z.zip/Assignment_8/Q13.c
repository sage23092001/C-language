#include<stdio.h>
int main()
{
    int i,j,k,n,c;
    for(i=0;i<=7;i++)
    {
        c='A';
        for(j=1;j<=7-i;j++)
        {
            printf("%c",c);
            c++;
        }
        for(k=1;k<=2*i-1;k++)
        {
            printf(" ");
        }
        if(i==0)
        {
             c--;
             c--;
             for(n=j-1-1;n>=1;n--)
             {
                printf("%c",c);
                c--;
             }
        }
        if(i>0)
        {
             c--;
             for(n=j-1;n>=1;n--)
             {
                 printf("%c",c);
                 c--;
             }
        }
        printf("\n");
    }
    return 0;
}
