#include<stdio.h>
int main()
{
    int i,j,k,n;
    for(i=1;i<=4;i++)
    {
        for(j=1;j<=4-i;j++)
        {
            printf(" ");
        }
        for(k=1;k<=4-(j-1);k++)
        {
            printf("%d",k);
        }
        for(n=k-1-1;n>=1;n--)
        {
            printf("%d",n);
        }
        printf("\n");
    }
    return 0;
}
