#include<stdio.h>
int main()
{
    float a,b,c,d,e,avg;
    printf("Enter marks of each subject: ");
    scanf("%f %f %f %f %f",&a,&b,&c,&d,&e);
    avg=(a+b+c+d+e)/5.0;
    printf("%f",avg);
    if(avg>33)
    {
        printf("\nPassed");
    }
    else
    {
        printf("\nfailed");
    }
    getch();
    return 0;
}
