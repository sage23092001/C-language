#include<stdio.h>
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    if((n|1)==n+1)
        printf("%d is even number",n);
    else                 //(n|1)==n
        printf("%d is odd number",n);
    getch();
    return 0;
}
