#include<stdio.h>
int main()
{
    int x;
    printf("Enter a month number: ");
    scanf("%d",&x);
    if(x==1)
    {
        printf("31 days");
    }
    if(x==2)
    {
        printf("28/29 days");
    }
     if(x==3)
    {
        printf("31 days");
    }
     if(x==4)
    {
        printf("30 days");
    }
     if(x==5)
    {
        printf("31 days");
    }
     if(x==6)
    {
        printf("30 days");
    }
     if(x==7)
    {
        printf("31 days");
    }
     if(x==8)
    {
        printf("31 days");
    }
     if(x==9)
    {
        printf("30 days");
    }
     if(x==10)
    {
        printf("31 days");
    }
     if(x==11)
    {
        printf("30 days");
    }
     if(x==12)
    {
        printf("31 days");
    }
    getch();
    return 0;
}
