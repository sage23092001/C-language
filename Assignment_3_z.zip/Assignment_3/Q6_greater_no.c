#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter a two numbers: ");
    scanf("%d %d",&a,&b);
    if(a>b)
        printf("%d is a greater number",a);
    if(b>a)
        printf("%d is a greater number",b);
    if(a==b)
        printf("%d",a);
    getch();
    return 0;
}
