#include<stdio.h>
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    if(0<(n/100))
    {
        if((n/100)<10)
            printf("%d is a three digit number",n);
        else
            printf("%d is not a three digit number",n);
    }
    else
        printf("%d is not a three digit number",n);
    getch();
    return 0;
}
