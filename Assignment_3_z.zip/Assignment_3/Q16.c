#include<stdio.h>
int main()
{
    int x;
    char ch;
    printf("Enter a character: ");
    scanf("%c",&ch);
    x=ch;
    if(x>=65)
    {
        if(x<=90)
            printf("%c is a uppercase alphabet",ch);
        else
        {
            if(x>=97)
            {
                if(x<=122)
                    printf("%c is a lowercase alphabet",ch);
            }
        }
    }
    else
    {
        if(x>=48)
        {
            if(x<=57)
                printf("%c is a digit",ch);
        }
        else
        {
            printf("%c is a special character",ch);
        }
        getch();
        return 0;
    }

}
