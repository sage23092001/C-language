#include<stdio.h>
int main()
{
    float cp,sp,p,l;
    printf("Enter a cost price and selling price: ");
    scanf("%d %d",&cp,&sp);
    p=((sp-cp)/cp*100);
    l=((cp-sp)/sp*100);
    if(cp<sp)
    {
        printf("Profit in percentage is %f",p);
    }
    else
    {
        printf("Loss in percentage is %f",l);
    }
    getch();
    return 0;
}
