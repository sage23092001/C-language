#include<stdio.h>
int main()
{
    int x;
    char ab;
    printf("Enter a alphabet: ");
    scanf("%c",&ab);
    x=ab;
    if(65<=x)
    {
        if(x<=90)
            printf("%c is a uppercase alphabet",ab);
        else
            printf("%c is a lowercase alphabet",ab);
    }

    getch();
    return 0;
}
