#include<stdio.h>
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    if((n%7)==0)
    {
        if((n%3)==0)
        {
            printf("%d is divisible by 7 and 3",n);
        }
        else
        {
            printf("%d is divisible by 7",n);
        }

    }
    else
    {
        if((n%3)==0)
        {
            printf("%d is divisible by 3",n);
        }
        else
            printf("%d is not divisible by 7 and 3",n);
    }
    getch();
    return 0;
}
