#include<stdio.h>
int main()
{
    int a,b,c;
    printf("Enter the sides of a triangle: ");
    scanf("%d %d %d",&a,&b,&c);
    if(a+b>c)
    {
        if(b+c>a)
        {
            if(c+a>b)
                printf("The given triangle is valid");
            else
                printf("The given triangle is not valid");
        }
    }
    else
    {
        printf("The given triangle is not valid");
    }
    getch();
    return 0;
}
