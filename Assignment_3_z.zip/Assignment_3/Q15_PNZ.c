#include<stdio.h>
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    if(n>0)
    {
        printf("%d is a positive number",n);
    }
    if(n<0)
    {
        printf("%d is a negative number",n);
    }
    if(n==0)
        printf("zero");
    getch();
    return 0;
}
