#include<stdio.h>
int main()
{
    int i,n,a=0,b=1,sum=0;
    printf("Print first n numbers of fibonnaci series: ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=a+b;
        printf(" %d",a);
        a=b;
        b=sum;
    }
    getch();
    return 0;
}
