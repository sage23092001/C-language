#include<stdio.h>
int main()
{
    int i,j,n,m;
    printf("Enter two numbers: ");
    scanf("%d %d",&n,&m);
    printf("Prime numbers between %d and %d:\n ",n,m);
    n=n+1;
    m=m-1;
    for(i=n;i<=m;i++)
    {
        for(j=2;j<i;j++)
        {
            if((i%j)==0)
            break;
        }
        if(i==j)
        {
            printf(" %d",i);
        }
    }
    getch();
    return 0;
}
