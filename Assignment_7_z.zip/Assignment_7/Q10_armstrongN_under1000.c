#include<stdio.h>
int main()
{
    int i,n,m,d,j,k,r=0,sum,x=0;
    printf("Armstrong numbers under 1000 are: ");
    for(i=1;i<=1000;i++)
    {
        n=i;
        m=n;
        sum=0;
        for(d=0;n>0;d++)
        {
            n=n/10;
        }
        for(j=1;m>0;j++)
        {
            r=m%10;
            x=r;
            for(k=1;k<d;k++)
            {
                r=r*x;
            }
            sum=sum+r;
            m=m/10;

        if(sum==i)
            printf(" %d",i);
        }
    }
    getch();
    return 0;
}
