#include<stdio.h>
int main()
{
    int i,n,x,a=0,b=1,sum=0;
    printf("Enter the term you want: ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
          sum=a+b;
          x=a;
          a=b;
          b=sum;
    }
    printf("%d",x);
    getch();
    return 0;
}
