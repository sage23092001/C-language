#include<stdio.h>
int main()
{
    int i,n,a=0,b=1,sum=0;
    printf("Enter a number: ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        sum=a+b;
        a=b;
        b=sum;
        if(n==sum)
        {
            printf("%d is from fibonnaci series",n);
            break;
        }
    }
    if(i==n+1)
    {
        printf("%d is not from fibonnaci series",n);
    }
    getch();
    return 0;
}
