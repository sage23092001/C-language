#include<stdio.h>
int main()
{
    int i,n,m,x;
    printf("Enter two numbers: ");
    scanf("%d %d",&n,&m);
    if(n<m)
    {
        x=m;
    }
    else
    {
        x=n;
    }
    for(i=2;i<=x;i++)
    {
        if((n%i)==0)
        {
            if((m%i)==0)
            {
                printf("%d and %d are not co-prime numbers",n,m);
                break;
            }
        }
    }
    if(i==x+1)
    {
        printf("%d and %d are co-prime numbers",n,m);
    }
    getch();
    return 0;
}
