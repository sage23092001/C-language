#include<stdio.h>
int main()
{
    int n,m,k,d,i,j,r=0,sum=0,x=0;
    printf("Enter a number: ");
    scanf("%d",&n);
    m=n;
    k=m;
    for(d=0;k>0;d++)
    {
        k=k/10;
    }
    for(i=1;m>0;i++)
    {
        r=m%10;
        x=r;
        for(j=1;j<=d-1;j++)
        {
            r=r*x;
        }
        sum=sum+r;
        m=m/10;
    }
    if(sum==n)
         printf("%d is an armstrong number",n);
    else
        printf("%d is not an armstrong number",n);
    getch();
    return 0;
}
