#include<stdio.h>
int main()
{
    int i,x,n,m,s=0;
    printf("Enter two numbers: ");
    scanf("%d %d",&n,&m);
    if(n<m)
        x=n;
    else
        x=m;
    for(i=1;i<=x;i++)
    {
        if((n%i)==0)
        {
            if((m%i)==0)
            {
                s=i;
            }
        }
    }
    printf("%d is the HCF of %d and %d",s,n,m);
    getch();
    return 0;
}
