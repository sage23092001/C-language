#include<stdio.h>
int main()
{
    int i,j,n,x;
    printf("Enter a number: ");
    scanf("%d",&n);
    for(i=n+1;i>=n+1;i++)
    {
        for(j=2;j<i;j++)
        {
            x=i%j;
        }
        if(x!=0)
            {
                if(i==j)
                {
                    printf("Next prime number from %d: %d",n,i);
                }
            }
        break;
    }
    return 0;
}
