#include<stdio.h>
int main()
{
    int i;
    char s[20];
    printf("Enter a string: ");
    gets(s);
    for(i=0;s[i]!='\0';i++);
    printf("Length of a string is %d ",i);
    getch();
    return 0;
}
