#include<stdio.h>
int main()
{
    int H,M;
    printf("Enter a time: ");
    scanf("%d:%d",&H,&M);
    printf("%d hour and %d minute",H,M);
    getch();
    return 0;
}
