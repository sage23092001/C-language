#include<stdio.h>
int main()
{
    printf("\"\\n\"");
    getch();
    return 0;
}
