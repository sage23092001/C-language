#include<stdio.h>
int main()
{
    int D,M,Y;
    printf("Enter a date: ");
    scanf("%d/%d/%d",&D,&M,&Y);
    printf("Day - %d, Month - %d, Year - %d",D,M,Y);
    getch();
    return 0;
}
