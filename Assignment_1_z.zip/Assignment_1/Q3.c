#include<stdio.h>
int main()
{
 printf("\"MySirG\"");
 getch();
 return 0;
}
