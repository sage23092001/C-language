#include<stdio.h>
int main()
{
  printf("Hello\nStudents");
  getch();
}
