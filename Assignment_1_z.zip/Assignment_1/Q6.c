#include<stdio.h>
int main()
{
    char s[20];

    printf("Enter your name: ");
    scanf("%s",&s);
    printf("\"%s\"",s);
    getch();
    return 0;
}
