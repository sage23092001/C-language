#include <stdio.h>

int main()
{
 float r,A,pi=3.14;
 printf("Enter a radius of the circle: ");
 scanf("%f",&r);
 A=pi*r*r;
 printf("Area of circle is %f having the radius %f",A,r);
 getch();
}
