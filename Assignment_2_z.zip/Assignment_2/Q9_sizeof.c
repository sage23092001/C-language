#include<stdio.h>
int main()
{
    int x;
    printf("Check the size of:\n1. i = int\n2. f = float\n3. c = char\n4. d = double");
    printf("\nEnter the command: ");
    scanf("%d",&x);
    if(x==1)
        printf("%d bytes",sizeof(int));
    if(x==2)
        printf("%d bytes",sizeof(float));
    if(x==3)
        printf("%d bytes",sizeof(char));
    if(x==4)
        printf("%d bytes",sizeof(double));
    getch();
    return 0;
}
