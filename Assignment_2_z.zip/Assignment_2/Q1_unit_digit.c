#include<stdio.h>
int main()
{
    int a;
    printf("Enter a number: ");
    scanf("%d",&a);
    printf("Unit digit: %d",a%10);
    getch();
    return 0;
}
