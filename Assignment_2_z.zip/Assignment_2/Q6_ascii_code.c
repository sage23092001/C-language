#include<stdio.h>
int main()
{
    char ch;
    printf("Enter a character: ");
    scanf("%c",&ch);
    printf("%d",ch);
    getch();
    return 0;
}
