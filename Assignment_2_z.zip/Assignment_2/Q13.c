#include<stdio.h>
int main()
{
    int n,rt;
    printf("Enter a three digit number: ");
    scanf("%d",&n);
    rt=(n%10)*100+n/10;
    printf("Resulting number of one position rotate from right is %d",rt);
    getch();
    return 0;
}
