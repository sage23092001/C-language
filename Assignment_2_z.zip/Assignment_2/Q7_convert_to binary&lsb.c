#include<stdio.h>
int main()
{
    int i,j,n,a[10];
    printf("Enter a number: ");
    scanf("%d",&n);
    for(i=0;n>0;i++)
    {
        a[i]=n%2;
        n=n/2;
        printf("%d",a[i]);
    }

    for(j=i-1;j>=0;j--)
    {
       if(a[j]=1)
      {
        printf("\n%d",j);
      }
      break;
    }

    getch();
    return 0;
}
