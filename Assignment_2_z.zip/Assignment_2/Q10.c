#include<stdio.h>
int main()
{
    int n;
    printf("Enter a number: ");
    scanf("%d",&n);
    printf("Replacing the last digit of %d with 0: %d",n,n/10*10);
    getch();
    return 0;
}
