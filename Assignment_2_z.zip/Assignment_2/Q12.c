#include<stdio.h>
int main()
{
    float amount;
    printf("Enter the amount in INR: ");
    scanf("%f",&amount);
    printf("%f INR = %f USD",amount,amount/76.23);
    getch();
    return 0;
}
