#include<stdio.h>
int main()
{
    int number,digit;
    printf("Enter a number and digit: ");
    scanf("%d %d",&number,&digit);
    printf("The resulting number of given number=%d and digit=%d is %d",number,digit,number*10+digit);
    getch();
    return 0;
}
