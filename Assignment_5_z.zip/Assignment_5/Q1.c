#include<stdio.h>
int main()
{
    int i,n;
    printf("Print MySirG n times:");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
        printf("MysirG\n");
    getch();
    return 0;
}
