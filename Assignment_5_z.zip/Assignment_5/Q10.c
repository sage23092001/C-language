#include<stdio.h>
int main()
{
    int i,n;
    printf("Table of :");
    scanf("%d",&n);
    for(i=1;i<=10;i++)
    {
        printf("%d ",n*i);
    }
    getch();
    return 0;
}
