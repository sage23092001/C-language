#include<stdio.h>
int main()
{
    int i,n;
    printf("First n odd natural numbers:");
    scanf("%d",&n);
    for(i=1;i<=n*2;i++)
    {
        if((i%2)==1)
            printf(" %d",i);
    }
    getch();
    return 0;
}
