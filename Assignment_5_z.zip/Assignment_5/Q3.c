#include<stdio.h>
int main()
{
    int i,n;
    printf("First n natural numbers in reverse:");
    scanf("%d",&n);
    for(i=n;i>=1;i--)
        printf("%d ",i);
    getch();
    return 0;
}
