#include<stdio.h>
int main()
{
    int i,n;
    printf("Square of n natural numbers:");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        printf("%d ",i*i);
    }
    getch();
    return 0;
}
