#include<stdio.h>
int main()
{
    int i,n;
    printf("First n odd natural numbers in reverse:");
    scanf("%d",&n);
    for(i=n*2;i>=1;i--)
    {
        if((i%2)==1)
           printf("%d ",i);
    }
    getch();
    return 0;
}
